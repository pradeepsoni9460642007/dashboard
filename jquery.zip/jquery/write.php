<html>
   <head>
      <title>The jQuery Example</title>
      <script type = "text/javascript" 
         src = "js/jquery.min.js"></script>
      <script type = "text/javascript">
      $(document).ready(function(){
		  console.log("document loaded");
	  });
	  $(window).load(function(){
		  console.log("window loaded");
	  });
	  </script> 
   </head>
      <a href="asdf">Hello</a>
<script>
alert($("a").attr("href"));
</script>	  
   <body>
   </body>

  
	
	
</html> 